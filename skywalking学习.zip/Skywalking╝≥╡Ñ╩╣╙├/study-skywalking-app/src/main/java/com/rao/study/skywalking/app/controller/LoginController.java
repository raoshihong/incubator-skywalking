package com.rao.study.skywalking.app.controller;

import com.rao.study.skywalking.app.dto.UserDto;
import com.rao.study.skywalking.app.service.LoginService;
import com.rao.study.skywalking.app.vo.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

    @Autowired
    private LoginService myLoginService;

    @PostMapping(value = {"/login"})
    public ResponseVo<Boolean> login(@RequestBody UserDto userDto){
        boolean flag = myLoginService.login(userDto.getMobile(),userDto.getPassword());
        return new ResponseVo<Boolean>(flag);
    }
}
