package com.rao.study.skywalking.app.dto;

import lombok.Data;


@Data
public class UserDto {

    private String mobile;
    private String password;
}
