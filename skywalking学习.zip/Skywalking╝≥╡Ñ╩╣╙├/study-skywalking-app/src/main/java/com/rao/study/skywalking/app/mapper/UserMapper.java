package com.rao.study.skywalking.app.mapper;

import com.rao.study.skywalking.app.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {

    @Select("select * from users u where u.mobile = #{mobile} and u.password = #{password}")
    User selectByMobileAndPwd(@Param("mobile") String mobile,@Param("password") String password);

}
