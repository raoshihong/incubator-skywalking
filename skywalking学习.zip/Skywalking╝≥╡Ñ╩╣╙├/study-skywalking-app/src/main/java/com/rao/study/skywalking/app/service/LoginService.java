package com.rao.study.skywalking.app.service;

import com.rao.study.skywalking.app.model.User;
import com.rao.study.skywalking.app.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    @Autowired
    private UserMapper userMapper;

    public boolean login(String mobile,String password){
        User user = userMapper.selectByMobileAndPwd(mobile,password);
        return user != null;
    }

}
