package com.rao.study.skywalking.app.vo;

import lombok.Data;

@Data
public class ResponseVo<T> {
    private T data;

    public ResponseVo(T data) {
        this.data = data;
    }
}
